package com.example.appmovilunab.password;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

//import androidx.appcompat.app.AppCompatActivity;

import com.example.appmovilunab.R;

public class FinCambioPassword extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fin_cambio_password);
    }
}