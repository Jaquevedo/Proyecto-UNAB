package com.example.appmovilunab;

public class RegistroExitosoActivity {
}
