package com.example.appmovilunab.password;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;


import com.example.appmovilunab.R;

public class CambioPassword extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cambio_password);
    }
}