package com.example.appmovilunab;

public class LoginPagPricActivity {
}
