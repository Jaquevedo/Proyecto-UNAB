package com.aplication.aplicationunab_v2.activitys.profesores;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

import com.aplication.aplicationunab_v2.R;

public class SintomasProfesores extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sintomas_profesores);
    }
}