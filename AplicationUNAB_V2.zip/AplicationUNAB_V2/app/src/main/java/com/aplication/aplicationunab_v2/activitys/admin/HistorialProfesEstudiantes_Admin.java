package com.aplication.aplicationunab_v2.activitys.admin;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

import com.aplication.aplicationunab_v2.R;

public class HistorialProfesEstudiantes_Admin extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_historial_profes_estudiantes_admin);
    }
}